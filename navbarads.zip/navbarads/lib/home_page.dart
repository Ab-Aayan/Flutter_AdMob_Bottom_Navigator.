import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'ad_banner_widget.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      bottomNavigationBar: AdBannerWidget(),
      body: ListView(
        children: [
          Text('data'),
          // Your content here
          AdBannerWidget(), // Include the ad banner widget here
          // More content
        ],
      ),
    );
  }
}
